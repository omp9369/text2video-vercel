import React, { useState, useEffect } from 'react'
import { Mic, StopCircle } from 'lucide-react'
import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition'

const VoiceAssistant: React.FC = () => {
  const [isListening, setIsListening] = useState(false)
  const [response, setResponse] = useState('')
  const { transcript, resetTranscript } = useSpeechRecognition()

  useEffect(() => {
    if (!SpeechRecognition.browserSupportsSpeechRecognition()) {
      alert('Browser does not support speech recognition.')
    }
  }, [])

  const handleStartListening = () => {
    setIsListening(true)
    resetTranscript()
    SpeechRecognition.startListening({ continuous: true })
  }

  const handleStopListening = () => {
    setIsListening(false)
    SpeechRecognition.stopListening()
    processCommand(transcript)
  }

  const processCommand = (command: string) => {
    let resp = ''
    if (command.toLowerCase().includes('hello')) {
      resp = 'Hello! How can I assist you today?'
    } else if (command.toLowerCase().includes('time')) {
      resp = `The current time is ${new Date().toLocaleTimeString()}.`
    } else {
      resp = 'Sorry, I didn\'t understand that. Try saying "hello" or "what time is it".'
    }
    setResponse(resp)
    speak(resp)
  }

  const speak = (text: string) => {
    const utterance = new SpeechSynthesisUtterance(text)
    speechSynthesis.speak(utterance)
  }

  return (
    <div className="w-full max-w-md bg-white rounded-lg shadow-lg p-6 flex flex-col items-center">
      <button
        onClick={isListening ? handleStopListening : handleStartListening}
        className={`p-4 rounded-full ${isListening ? 'bg-error' : 'bg-primary'} text-white mb-4`}
      >
        {isListening ? <StopCircle size={48} /> : <Mic size={48} />}
      </button>
      <p className="text-lg text-neutral-800 mb-4">Transcript: {transcript || 'Speak something...'}</p>
      <p className="text-lg text-accent">Response: {response}</p>
    </div>
  )
}

export default VoiceAssistant