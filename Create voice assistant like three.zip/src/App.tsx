import React from 'react'
import VoiceAssistant from './components/VoiceAssistant'

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-neutral-100 flex flex-col items-center justify-center p-4">
      <h1 className="text-4xl font-heading text-primary mb-8">Om Voice Assistant</h1>
      <VoiceAssistant />
    </div>
  )
}

export default App