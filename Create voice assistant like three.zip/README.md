# Om Voice Assistant

A voice-controlled assistant inspired by Siri, named Om, fully controllable on mobile devices.

## Setup

1. Install dependencies: `npm install`
2. Run development server: `npm run dev`